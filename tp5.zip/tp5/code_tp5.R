rm(list=ls())

library(DBI)

#Connection postgre server
source(file = "tp5/connexion_db.R")
conn<-connecter()
DBI::dbListTables(conn)

# Q2 Var dans popnaiss_com
DBI::dbListFields(conn,"popnaiss_com")

# Q3 Copie de la table popnaiss_com
#Nature de popnaiss_com2 : Formal class PqResult
popnaiss_com2 = dbSendQuery(conn, "SELECT * FROM popnaiss_com")
summary(popnaiss_com2)
str(popnaiss_com2)
#dbFetch()

# Q4
#Nature with dbGetQuery : dataframe
str(dbGetQuery(conn, "SELECT * FROM popnaiss_com"))

# Q5
rennes = dbGetQuery(conn, "SELECT * FROM popnaiss_com WHERE codgeo = '35238' ")

# Q6 Join bpe_metro et naissances pour la ville de Bruz (table popnaiss_com).
# jointure sur la commune de Bruz (CODGEO = “35047”). 
#Vous utiliserez l’instruction INNER JOIN en terminant avec l’instruction WHERE

dbGetQuery(conn, "SELECT * FROM bpe21_metro")
equipement = dbGetQuery(conn, 
           "SELECT * FROM bpe21_metro INNER JOIN popnaiss_com ON 
           bpe21_metro.depcom = popnaiss_com.codgeo
           WHERE CODGEO='35047'")
# Q7
# a

library(dplyr)
library(dbplyr)

# Connexion à la table popnaiss
popnaiss<-tbl(conn,"popnaiss_com")
str(popnaiss) # ! ce n'est pas un data.frame

# Reprise de la question 5
popnaiss %>% 
  filter(codgeo=="35047") %>% 
  show_query() #traduit la requete en SQL

pop_bruz <- popnaiss %>% 
  filter(codgeo=="35047") %>% 
  collect() #retrieves data into a local tibble
str(pop_bruz)

# b
bpe21 = tbl(conn, "bpe21_metro")
str(bpe21)

bpe21 %>% filter(depcom=='35047') %>% 
  inner_join(popnaiss, by=c('depcom'= 'codgeo')) %>% 
  show_query()

bpe21 %>%
  inner_join(popnaiss, by=c('depcom'= 'codgeo')) %>% 
  filter(depcom=='35047') %>% 
  show_query()

bpe21_popnaiss = bpe21 %>%
  inner_join(popnaiss, by=c('depcom'= 'codgeo')) %>% 
  filter(depcom=='35047') %>% 
  collect()

bpe21_popnaiss2 = bpe21 %>% filter(depcom=='35047') %>% 
  inner_join(popnaiss, by=c('depcom'= 'codgeo')) %>% 
  collect()

# Une var en plus with Q6, join av ou ap the same

###########Exercice 3##########

# Q1 A partir de la table bpe21_metro, créer une table bpe_dep50
#pour le département de la Manche (DEP=‘50’). 
#keep variables ID, DEPCOM, DOM, SDOM, TYPEQU, GEOMETRY. 
#type d’objet retourné: data.frame
bpe21_mt = bpe21 %>% collect()

bpe_dep50 = bpe21 %>% filter(dep =='50') %>% 
  select(id, depcom, dom, sdom, typequ, geometry) %>% 
  collect()

# Q2

bpe_dep50_stread = st_read(conn, 
                           query="SELECT id, depcom, dom, sdom, typequ, geometry
                           FROM bpe21_metro WHERE dep= '50' ")
# Q3
st_crs(bpe_dep50_stread)
dbGetQuery(conn, "SELECT DISTINCT(ST_SRID(geometry)) FROM bpe21_04;")

# Q4
# Dénombrer les maternités TYPEQU=‘D107’ par region et trier par ordre décroissant. 
#Vous utiliserez la table bpe21_metro et les variable REG et TYPEQU en particulier. 
#Chaque équipement possède un identifiant (ID). 
#Pour compter les maternités, vous devrez donc compter les identifiants. 
#Faites cela soit en utilisant sf+dplyr soit en utilisant une requête SQL.

#dbGetQuery(conn, "SELECT COUNT(*) AS total WHERE TYPEQU= 'D107' GROUP BY depcom
#           ORDER BY total DESC")
nb_maternity = tbl(conn, "bpe21_metro") %>% select(id, reg, typequ) %>% 
  filter(typequ== 'D107') %>% 
  group_by(reg) %>% 
  summarize(total = n()) %>% 
  arrange(desc(total)) %>% 
  collect()

# Q5
# Sélectionner les cinémas (TYPEQU=‘F303’) dans un rayon d’un 1km autour 
#de la Sorbonne (5e arrondissemnt de Paris). 
#On pourra utiliser les coordoonnées (long,lat) suivantes (lat = 48.84864, long = 2.34297) 
#pour situer La Sorbonne. 
#Attention, les coordonnées de longitude et de lattitude font référence au système WGS84 (CRS 4326)

cinema_bpe = tbl(conn, "bpe21_metro") %>% filter(typequ== 'F303') %>%  collect()

# b
# On construit un buffer de 1km (une zone tampon) autour de la sorbonne
# df des coordonnées
sorbonne_buffer <- data.frame(x=2.34297,y=48.84864) %>% 
  #qu'on transforme en objet sf (systeme de proj WGS84 => crs=4326)
  st_as_sf(coords = c("x","y"), crs = 4326) %>% 
  # on reprojette en LAMBERT-93 (crs=2154)
  st_transform(2154) %>% 
  # on crée la zone tampon autour du point (l'unité est le mètre ici)
  st_buffer(1000) 

str(sorbonne_buffer) # le buffer est constitué d'un unique polygône
plot(sorbonne_buffer %>% st_geometry()) # qui s'avère être un cercle

# c
# Transformer cinema_bpe en sf
cinema_bpe = st_read(conn, query="SELECT * FROM bpe21_metro WHERE TYPEQU= 'F303' ")
#cine_sorbonne = st_contains(sorbonne_buffer, cinema_bpe) direct liste des cine qui m'interessent
cine_sorbonne_list = st_within(cinema_bpe, sorbonne_buffer)

cine_1km_sorbonne = cinema_bpe %>%  filter(lengths(cine_sorbonne_list)>0)
cine_1km_sorbonne %>% nrow()

# Q6
library(leaflet)
# Optionnel :
# On récupère une icone spécifique sur https://ionic.io/ionicons (mot clé film)
cinemaIcons <- makeIcon(iconUrl = "images/film-sharp.png", 18,18)

leaflet() %>% 
  setView(lat = 48.84864, lng = 2.34297, zoom = 15) %>% 
  addTiles() %>% 
  addMarkers(lat = 48.84864, lng = 2.34297) %>% 
  addCircles(
    lat = 48.84864, lng = 2.34297, weight = 1, radius = 1000
  ) %>% 
  addMarkers(data = cine_1km_sorbonne %>% st_transform(4326))


# Remarque : 1000m en LAMBERT-93 ce n'est pas exactement 1000m en WGS84 (zoomez sur la carte suivante)
leaflet() %>%
  setView(lat = 48.84864, lng = 2.34297, zoom = 15) %>%
  addTiles() %>%
  addCircles(
    lat = 48.84864, lng = 2.34297, weight = 1, radius = 1000
  ) %>%
  addPolygons(data=sorbonne_buffer %>% st_transform(4326), col = "red")

